export const cameraService = {
  stream: null,
  
  async startCamera() {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 320, height: 240 },
        audio: false 
      });
      return this.stream;
    } catch (error) {
      console.error('Error accessing camera:', error);
      throw new Error('Camera access denied or not available');
    }
  },

  stopCamera() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
  },

  captureScreenshot(videoElement) {
    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    
    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoElement, 0, 0);
    
    return canvas.toDataURL('image/jpeg', 0.8);
  },

  async setupPeriodicCapture(videoElement, callback, interval = 10000) {
    const captureInterval = setInterval(() => {
      if (videoElement && videoElement.videoWidth > 0) {
        const screenshot = this.captureScreenshot(videoElement);
        callback(screenshot);
      }
    }, interval);

    return captureInterval;
  }
};