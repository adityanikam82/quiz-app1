export const storageService = {
  // User management
  saveUser(userData) {
    const users = this.getUsers();
    const existingUserIndex = users.findIndex(u => u.email === userData.email);
    
    if (existingUserIndex >= 0) {
      users[existingUserIndex] = { ...users[existingUserIndex], ...userData };
    } else {
      users.push({
        id: Date.now().toString(),
        ...userData,
        createdAt: new Date().toISOString()
      });
    }
    
    localStorage.setItem('quiz_users', JSON.stringify(users));
    return userData;
  },

  getUsers() {
    const users = localStorage.getItem('quiz_users');
    return users ? JSON.parse(users) : [];
  },

  getUserByEmail(email) {
    const users = this.getUsers();
    return users.find(u => u.email === email);
  },

  // Quiz results
  saveQuizResult(userId, quizData) {
    const results = this.getQuizResults();
    const result = {
      id: Date.now().toString(),
      userId,
      ...quizData,
      completedAt: new Date().toISOString()
    };
    
    results.push(result);
    localStorage.setItem('quiz_results', JSON.stringify(results));
    return result;
  },

  getQuizResults() {
    const results = localStorage.getItem('quiz_results');
    return results ? JSON.parse(results) : [];
  },

  getQuizResultsByUser(userId) {
    const results = this.getQuizResults();
    return results.filter(r => r.userId === userId);
  },

  // Screenshots
  saveScreenshot(userId, quizId, screenshot) {
    const screenshots = this.getScreenshots();
    const screenshotData = {
      id: Date.now().toString(),
      userId,
      quizId,
      screenshot,
      timestamp: new Date().toISOString()
    };
    
    screenshots.push(screenshotData);
    localStorage.setItem('quiz_screenshots', JSON.stringify(screenshots));
    return screenshotData;
  },

  getScreenshots() {
    const screenshots = localStorage.getItem('quiz_screenshots');
    return screenshots ? JSON.parse(screenshots) : [];
  },

  getScreenshotsByUser(userId) {
    const screenshots = this.getScreenshots();
    return screenshots.filter(s => s.userId === userId);
  },

  // Current user session
  setCurrentUser(user) {
    localStorage.setItem('current_user', JSON.stringify(user));
  },

  getCurrentUser() {
    const user = localStorage.getItem('current_user');
    return user ? JSON.parse(user) : null;
  },

  clearCurrentUser() {
    localStorage.removeItem('current_user');
  },

  // Initialize admin user
  initializeAdmin() {
    const adminUser = {
      email: 'admin@quiz.com',
      password: 'admin123',
      name: 'Quiz Administrator',
      role: 'admin'
    };
    
    const existingAdmin = this.getUserByEmail(adminUser.email);
    if (!existingAdmin) {
      this.saveUser(adminUser);
    }
  }
};

// Initialize admin on service load
storageService.initializeAdmin();