const GEMINI_API_KEY = 'AIzaSyD0zTg3tgI6XCVH49IC4NEBjySY_qMdWO4';
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent';

export const geminiService = {
  async generateQuestions(subject, count = 10) {
    try {
      const prompt = `Generate ${count} multiple choice questions about ${subject}. Each question should have 4 options (A, B, C, D) with only one correct answer. Format the response as a JSON array with this structure:
      [
        {
          "question": "Question text here",
          "options": {
            "A": "Option A text",
            "B": "Option B text", 
            "C": "Option C text",
            "D": "Option D text"
          },
          "correctAnswer": "A",
          "explanation": "Brief explanation of why this is correct"
        }
      ]
      
      Make questions challenging but fair for intermediate level students. Topics for ${subject}:
      ${this.getSubjectTopics(subject)}`;

      const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: prompt
            }]
          }]
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Gemini API Error:', errorData);
        throw new Error(`Failed to generate questions. Status: ${response.status}. Message: ${errorData.error?.message || 'Unknown error'}`);
      }

      const data = await response.json();
      if (!data.candidates || !data.candidates[0] || !data.candidates[0].content || !data.candidates[0].content.parts || !data.candidates[0].content.parts[0]) {
        console.error('Invalid Gemini API response structure:', data);
        throw new Error('Invalid response format from Gemini API');
      }
      const generatedText = data.candidates[0].content.parts[0].text;
      
      const jsonMatch = generatedText.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      console.error('Could not extract JSON from Gemini response:', generatedText);
      throw new Error('Invalid response format - no JSON array found');
    } catch (error) {
      console.error('Error generating questions:', error);
      return this.getFallbackQuestions(subject);
    }
  },

  async evaluateAnswer(question, userAnswer, correctAnswer) {
    try {
      const prompt = `Evaluate this quiz answer.
      Question: "${question}"
      User's Answer: "${userAnswer}"
      Correct Answer: "${correctAnswer}"
      
      Is the user's answer correct?
      Provide a concise evaluation (1-2 sentences) explaining why the user's answer is correct or incorrect, and offer a brief explanation of the correct concept if the user was wrong. Be encouraging.`;

      const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: prompt
            }]
          }]
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Gemini API Error (evaluateAnswer):', errorData);
        throw new Error(`Failed to evaluate answer. Status: ${response.status}. Message: ${errorData.error?.message || 'Unknown error'}`);
      }

      const data = await response.json();
      if (!data.candidates || !data.candidates[0] || !data.candidates[0].content || !data.candidates[0].content.parts || !data.candidates[0].content.parts[0]) {
        console.error('Invalid Gemini API response structure (evaluateAnswer):', data);
        throw new Error('Invalid response format from Gemini API for evaluation');
      }
      return data.candidates[0].content.parts[0].text;
    } catch (error) {
      console.error('Error evaluating answer:', error);
      // Fallback evaluation
      if (userAnswer === correctAnswer) {
        return `Correct! "${userAnswer}" is the right answer. Well done!`;
      } else {
        return `Not quite. The correct answer is "${correctAnswer}". Keep trying!`;
      }
    }
  },

  async generateHint(question, options) {
    try {
      const prompt = `Provide a subtle, one-sentence hint for the following multiple-choice question. The hint MUST NOT directly state or strongly imply the correct answer. It should only guide the user towards the general concept or area of knowledge related to the question. Do NOT mention any specific option letters (A, B, C, D) or the content of the options.
      Question: "${question}"
      Options: A) ${options.A}, B) ${options.B}, C) ${options.C}, D) ${options.D}
      
      Generate a single sentence hint that is vague enough not to give away the answer. For example, if the question is about a specific C++ keyword, a hint could be "Think about memory management in C++." or "Consider how objects are created."
      
      STRICT RULE: The hint must not contain any part of the correct answer's text.
      STRICT RULE: The hint must not contain any part of any option's text.`;

      const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: prompt
            }]
          }]
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Gemini API Error (generateHint):', errorData);
        throw new Error(`Failed to generate hint. Status: ${response.status}. Message: ${errorData.error?.message || 'Unknown error'}`);
      }

      const data = await response.json();
      if (!data.candidates || !data.candidates[0] || !data.candidates[0].content || !data.candidates[0].content.parts || !data.candidates[0].content.parts[0]) {
        console.error('Invalid Gemini API response structure (generateHint):', data);
        throw new Error('Invalid response format from Gemini API for hint');
      }
      
      let hintText = data.candidates[0].content.parts[0].text.trim();
      const allOptionsText = Object.values(options).join(" ").toLowerCase();
      const hintTextLower = hintText.toLowerCase();

      // Check if hint contains any part of any option
      for (const optionValue of Object.values(options)) {
        if (hintTextLower.includes(optionValue.toLowerCase())) {
          console.warn("Generated hint contained option text, providing generic hint.");
          return "Focus on the core principles related to the question's subject.";
        }
      }
      
      // Check if hint is too similar to the question itself
      if (hintTextLower.includes(question.toLowerCase().substring(0, 20))) { // Check first 20 chars
         console.warn("Generated hint was too similar to the question, providing generic hint.");
         return "Try to recall the main definitions associated with this topic.";
      }

      return hintText;
    } catch (error) {
      console.error('Error generating hint:', error);
      return "Think carefully about the key concepts involved in this question.";
    }
  },

  getSubjectTopics(subject) {
    const topics = {
      'C++': 'Object-oriented programming, pointers, memory management, STL, templates, inheritance, polymorphism, data structures',
      'Database': 'SQL queries, normalization, ACID properties, indexing, joins, transactions, NoSQL, database design',
      'Operating Systems': 'Process management, memory management, file systems, scheduling algorithms, deadlocks, synchronization',
      'Cloud Computing': 'AWS, Azure, GCP, containerization, microservices, serverless, scalability, cloud security'
    };
    return topics[subject] || 'General computer science concepts';
  },

  getFallbackQuestions(subject) {
    const fallbackData = {
      'C++': Array(10).fill(null).map((_, i) => ({
        question: `Fallback C++ Question ${i + 1}: What is a class in C++?`,
        options: { A: "A blueprint for objects", B: "A function", C: "A variable", D: "A loop" },
        correctAnswer: "A",
        explanation: "A class is a user-defined type that acts as a blueprint for creating objects."
      })),
      'Database': Array(10).fill(null).map((_, i) => ({
        question: `Fallback Database Question ${i + 1}: What is SQL?`,
        options: { A: "Structured Query Language", B: "Simple Query Language", C: "System Query Language", D: "Standard Query Language" },
        correctAnswer: "A",
        explanation: "SQL stands for Structured Query Language, used for managing relational databases."
      })),
      'Operating Systems': Array(10).fill(null).map((_, i) => ({
        question: `Fallback OS Question ${i + 1}: What is a process?`,
        options: { A: "A program in execution", B: "A file on disk", C: "A hardware component", D: "A network protocol" },
        correctAnswer: "A",
        explanation: "A process is an instance of a computer program that is being executed."
      })),
      'Cloud Computing': Array(10).fill(null).map((_, i) => ({
        question: `Fallback Cloud Question ${i + 1}: What is IaaS?`,
        options: { A: "Infrastructure as a Service", B: "Internet as a Service", C: "Information as a Service", D: "Integration as a Service" },
        correctAnswer: "A",
        explanation: "IaaS (Infrastructure as a Service) provides virtualized computing resources over the internet."
      }))
    };
    return fallbackData[subject] || fallbackData['C++'];
  }
};