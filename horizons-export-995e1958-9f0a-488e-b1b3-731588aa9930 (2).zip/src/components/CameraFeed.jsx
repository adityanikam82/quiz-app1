import React, { useEffect, useRef, useState } from 'react';
import { cameraService } from '@/services/cameraService';
import { storageService } from '@/services/storageService';
import { Camera, CameraOff } from 'lucide-react';
import { motion } from 'framer-motion';

const CameraFeed = ({ isActive, userName, onScreenshot }) => {
  const videoRef = useRef(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState(null);
  const intervalRef = useRef(null);

  useEffect(() => {
    if (isActive) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => stopCamera();
  }, [isActive]);

  const startCamera = async () => {
    try {
      const stream = await cameraService.startCamera();
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsStreaming(true);
        setError(null);
        
        intervalRef.current = await cameraService.setupPeriodicCapture(
          videoRef.current,
          handleScreenshot,
          10000 // 10 seconds
        );
      }
    } catch (err) {
      setError(err.message);
      setIsStreaming(false);
    }
  };

  const stopCamera = () => {
    cameraService.stopCamera();
    setIsStreaming(false);
    
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const handleScreenshot = (screenshot) => {
    const currentUser = storageService.getCurrentUser();
    if (currentUser && onScreenshot) {
      const screenshotData = storageService.saveScreenshot(
        currentUser.id,
        'current_quiz', // You might want to pass the actual quiz ID here
        screenshot
      );
      onScreenshot(screenshotData);
    }
  };

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className="fixed top-4 right-4 z-50"
    >
      <div className="bg-gray-900/90 backdrop-blur-sm rounded-lg p-3 border border-blue-500/30">
        <div className="flex items-center gap-2 mb-2">
          {isStreaming ? (
            <Camera className="w-4 h-4 text-green-400" />
          ) : (
            <CameraOff className="w-4 h-4 text-red-400" />
          )}
          <span className="text-xs text-white font-medium">
            {isStreaming ? 'Recording' : 'Camera Off'}
          </span>
        </div>
        
        {error ? (
          <div className="w-48 h-36 bg-red-900/50 rounded flex items-center justify-center">
            <span className="text-xs text-red-300 text-center px-2">
              {error}
            </span>
          </div>
        ) : (
          <div className="relative">
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              className="w-48 h-36 bg-gray-800 rounded camera-feed object-cover"
            />
            {isStreaming && (
              <div className="absolute bottom-1 left-1 bg-black/70 text-white text-xs px-2 py-1 rounded">
                {userName}
              </div>
            )}
            {isStreaming && (
              <div className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full pulse-glow"></div>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default CameraFeed;