
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { Trophy, CheckCircle, XCircle, Home, RotateCcw } from 'lucide-react';

const QuizResults = ({ results, onReturnHome, onRetakeQuiz }) => {
  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getScoreBadge = (score) => {
    if (score >= 80) return { variant: 'default', text: 'Excellent' };
    if (score >= 60) return { variant: 'secondary', text: 'Good' };
    return { variant: 'destructive', text: 'Needs Improvement' };
  };

  const scoreBadge = getScoreBadge(results.score);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 p-6">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center mb-8"
        >
          <div className="mb-6">
            <Trophy className={`w-16 h-16 mx-auto mb-4 ${getScoreColor(results.score)}`} />
            <h1 className="text-4xl font-bold text-white mb-2">Quiz Complete!</h1>
            <p className="text-gray-300">Here are your results for {results.section}</p>
          </div>
        </motion.div>

        {/* Score Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <Card className="bg-gray-900/50 backdrop-blur-sm border-gray-700">
            <CardHeader className="text-center">
              <CardTitle className="text-white">Your Score</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <div className={`text-6xl font-bold mb-4 ${getScoreColor(results.score)}`}>
                {results.score}%
              </div>
              <Badge variant={scoreBadge.variant} className="mb-4">
                {scoreBadge.text}
              </Badge>
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="text-center">
                  <p className="text-2xl font-bold text-white">{results.questions}</p>
                  <p className="text-gray-400 text-sm">Total Questions</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-400">{results.correctAnswers}</p>
                  <p className="text-gray-400 text-sm">Correct</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-red-400">
                    {results.questions - results.correctAnswers}
                  </p>
                  <p className="text-gray-400 text-sm">Incorrect</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Detailed Results */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-8"
        >
          <Card className="bg-gray-900/50 backdrop-blur-sm border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Question Review</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {results.answers.map((answer, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 * index }}
                    className="p-4 bg-gray-800/50 rounded-lg border border-gray-700"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-white font-medium flex-1">
                        Q{index + 1}: {answer.question}
                      </h4>
                      {answer.isCorrect ? (
                        <CheckCircle className="w-5 h-5 text-green-400 ml-2" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-400 ml-2" />
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                      <div>
                        <p className="text-sm text-gray-400">Your Answer:</p>
                        <p className={`font-medium ${
                          answer.isCorrect ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {answer.selectedAnswer === 'SKIPPED' ? 'Skipped' : answer.selectedAnswer}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Correct Answer:</p>
                        <p className="text-green-400 font-medium">{answer.correctAnswer}</p>
                      </div>
                    </div>
                    
                    {answer.evaluation && (
                      <div className="mt-3 p-3 bg-blue-500/10 border border-blue-500/20 rounded">
                        <p className="text-sm text-blue-300 font-medium mb-1">AI Evaluation:</p>
                        <p className="text-gray-300 text-sm">{answer.evaluation}</p>
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="flex gap-4 justify-center"
        >
          <Button
            onClick={onReturnHome}
            className="flex items-center gap-2 quiz-gradient text-white font-semibold px-8 py-3"
          >
            <Home className="w-4 h-4" />
            Return Home
          </Button>
          <Button
            onClick={onRetakeQuiz}
            variant="outline"
            className="flex items-center gap-2 px-8 py-3"
          >
            <RotateCcw className="w-4 h-4" />
            Retake Quiz
          </Button>
        </motion.div>
      </div>
    </div>
  );
};

export default QuizResults;
